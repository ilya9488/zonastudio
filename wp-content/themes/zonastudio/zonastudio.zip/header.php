<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Zonastudio
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- <link rel="profile" href="https://gmpg.org/xfn/11"> -->
	<link rel="shortcut icon" href="#">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	
	<header id="masthead" class="site-header <?php if(is_404()){ echo 'add_bg_bshad';} ?>">

		<div class="container-fluid">
			<div class="row "> <!-- align-items-center -->
				<!-- LOGO -->
				<div class="col-8 col-xl-2 col-lg-2">
					<a class="link-header-logo" href="<?php echo site_url(); ?>">
						<img class="header-logo" width="146" height="60" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAB8CAYAAADThI02AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABfESURBVHgB7Z0JtF1ldcd3IAjUoigIEkCfTDIJYYYgMTKJQgCZZRUN1iqgtNVVacViwZa2q0VqVZQuWorFAdDSYGUO8JhDSEgCCRkgJIGEzAwhIaEMp/9/9j7JzePlvTucc+459/1/a+11zrvvDufce759vm+Pg6yDSJJkF2x2h2wDeQcyHzJh0KBBL5kQovIMsg4AimowNidDNoPcAwW1IB77OORwyDN47D4TQlSaSissKKX3Y7MnZC/Iw1BK0zbwvIOw2RUyy3zG9ZYJISpHZRUWlNBO2BwBmQGZDiX0Sh/P5Xl+CHIg5H2Qbjx/oQkhKkXlFBaUz/bYHGZ+7LdA8fxfg6/fDpvjIXMhkyFL8R7vmBCi9FRGYUHRbInNkZBVkGcgz7WiaPB+nG118f3wPreaEKL0lF5hQbG819zztw+kG7IACma1ZQDe+w+wORiyLYT2LxrnV5kQopSUWmFBodCgPhRC+9TdUCZvWg7gcz5srrjoWXxE9i0hyknpFBaUx0bYDIEcA3keMg6yMm87Uxjmqbg+b+5NHIvPfNWEEKWhVAoLSoOevEPM46moMOZZG4gwiI9AXjP3KDZk2BdC5ENpFFYs/z4JeQIyEUribWsjOJ4PYkPF1QUZjeNZZEKIttJWhRXLv73NlQJnMffkZadqFhzjH2JzJoR2rUk4vvkmhGgLbVNYUARc9p0IWW4eEzWjrPFQkeazh7kDYIH5MlHR8kIUTOEKC4P/PdgMg+wMubNddqpmiBnh/pBDIcxNnIvjX2FCiEIoTGFhsG+Mzb7meX8M/JxS1cEey0Ta27Y2n21VRukKUWVyV1ixnGKYAvP+lkDGQ17GIE+swuC8NsGGgadc1lIBP49zetGEELmRq8KKSPLjIFwGPooBPdc6jFDInDnuBnkB8ljZHAdCdAq5KCwMYlZEYC0qxlTdAlmMQfyGdTDhROByl+d8u7l9S0nVQmRIpgorZhs0SDM3b7H5bGNABV2GsmbRQNbqehznP8uEEJmQicLCIN0cGwZaMh9vpXmRvGU2QAnFvYP5jIvcD3ldMy4hWqNlhYXBSU8Zgz+ZyvK/GJQvm1hLRPCPgEyCTMb3s9KEEE3RksLCYDwAm09AnoY8pdIsvRPLRAadsknGGHxPz5sQomGaUlgYgPSIMQ6J+XV3Kuq7PiJ+i2EQXC5PNFU7FaIhGlJYsfw7wdygPklxR80Ry0Sm+jCYdrSqQQhRH/0qrKgTtRVkP/N+f92QRZpVtUbEqH3U/HvlknqGltRC9E09CosNHziwmH4yVooqW6JVGWO3aOdiFsDcqmcBCJEXvSqsSPJld5pTzDvLjFeSb37UtCE7mn9CblO1UyHezbsUFgbPjuYVCfg/NiddYqIwwr5FoV3rrqwabgjRCaxVWOF6p/ePYQqs+jml3VU/ByrhTeRvQcP8TMiTnZ7aJEQ9DIr6VAz8ZBst2k/uM1EKwjB/lLk38Wn8NjNN5EJ0TmLwM2/cG8XDvGGzYxPHxVITbYcKi+V/mVbz677avYv2UFOeh97EqfiNnm3w9QfjNeOsAPBZ3zbPI82DK/MIo8ExM33qa5BPmY8D3iTSlQdj5Gi7Zbzhg5CrG/3+GzwWThxGxZ+sbvLf1iJ4T3r4v2BehnyO+TgvJG0urt2R5rm1zIC5CZ/9jLUC3nQE5ALIqZBdTJQS/Da7Q4Y2+DK+bpQVBD5rdpIfe1qG4P2GQK6ArG7gGOZBvgzZwnIA7/u5ms+aCTkkcYdMK++5I+TueE9uP2IFgc/aCjIxPnsF5IvWIoNje4N5a61DE9fyD2kKLDoVKitsroEca+vGAENKHjLvAJ4G8n7A3FzC5zGZnZ7zH5h3Ir/I8oUlxP8c8g3zzIgqwlXB3rHPDu6fhvyXtUD6Y73D6TZ+yN+Zf1HHY58/3HOQZYoLEnXyacsGLs0uNg+r4QyDymSOZUDMjv7JvLAkbVVPQX4M4bXPPpRvpM6mxJc0m5orqjMgXzLPB+Usi0vDa3OMS+Sxsanv45ArrZowTGdwzd+fxfe2eUsB0okvCbfs8dgmkGMhZ0H2MdF2kgosCbMCx3wO5KVYSsyCHGcZgPfZCHIa5JWaZdcRdb52MOR0yOJ4LZc6XZYhPZaEKdMgu1qTtGtJyBtDzecurzmfY60FNurtQZb4hdyF3d9DeMLnQnZIPKBUiNxIPLH+L82XY1yacTaUleeasyvOlJhdwGXWX+E6f7CeF8ZMikbwq829h1zqfNbyg0ZqGv35fVySuDe/SjB742PmgdBXQdKZ6NmJN6Rpij4VEKPbIbdi927zSqK8A2xjQuRA4mlKf2NuIyK3QX6VYQwaPWbHxD5DRO5v4LUWlTV+YZ77yaXOGZYfvzJfDqZLw7OsIoRCGmGe0vcS5Lfm9kFCRba3NUldM6ZoY3WHuR3hOBzQYXFxCZEJ4Q1j6R3arXhdsmbYZbj2XrPsoCJMzR/jm3Tv066bxsMd0spsoR/o/v+Z+YBnIDFnWR+0asAKxMxBplKnrY/ZMpz0cGZK58Xh1iR1L/FitsXod1r5afE/Pewqg02I1mHTkn8091ZzkP4z5EnLlq6a/UetCWJpmPah5MD8mOUDOy9xlnVj/E1j/0WJNzspO9uZp/fxHB6BzIeMje2anp6JB0U3TFM2KfxoY8ztWzywP8aH5xUsKAYAuH5or2KYwJB46B7I9SUubljbri4321K0i6MHc3Y8xCDvPO1mWUHvIGey9AY+GF5XLqMnxf8PMrcjNkzTRnQcxMJI4/mN+TLxeNm3RJP8qa2z0TDM4Lslr1ZRZF7nDMh3zJu7dEEuSzzXtJSEcyANEGWfTk5u1ugLbO6NxzlbPNiaoGWvHw6E03dOXReYG+X3lzdR1EviEexfNl9eMTXsR+b2K2FrDf20H3fHQyxOcI6VF4Zg7BT7j/SwQT5Ss3+aNUEmiiWmrqxRzmUip3ojGTtSkfW2aBPhuPkX86RjQm/SjSoZvT4x2/yWeWly8m18d4eWbWIQjhMa2+kcoK3v3h5PYRWYNBdzGJ6/nTVIZifMaHim88QykWtVBjmOLPP0VbQPBidj80fmzUwIE5svz9gr2DFEpY7rzJejDBc439z5VSZY6SL1DtKbOrX2n2HL+k38SfPRodYguWhoHBiNkmxRz9iLc+JusLkJsQ5erJeZV0dg3up3cN3MMdEXDHNg7BjH7dmQk5IWk6MzhkvBw2KfXthFvTzndvMUKE5kRjQaEJvblJLTegjtWtfEQyfi4D6pMAgR6SE/NA/kJP8O+R8TfRIK/fvmGQAcRyznU6bUuQPNi05yFvgAjndxL8+ZA3ks9hmP1WUNkPsamHErEMZgdEO4DGAu1/YyzA9MIm/1XHOTAaEX7EdaCtYNxxJjIWkjonI4v9mYphxIl/evmyes9wa9hUyHojOBDpfdrQEKUxq4IBeFfetO87D9kxOv8igGFsMhXze/9pgvd0nMxEUdhB3oUvPwD86yaAccbm0GY5lNVFKFNcu8TM+7CAfdAxA6EmgmOtIaoPBZDg6YFymjd9mN52icaEMHLKpLxOl9z7xDEAfer83LuojGoIJnQjHDQGh4/7vEa3y1EyrND8X+zaGYNgRzJNM4u2MasW+3ZVkWy8RZECaSvp54FUe6Ocvm9RAZESEMl9u6pSAdMt9Tc43GYWwW5D+we2s8xO+UAaWbWhuIcXuyuSGdv+fjiVd07VXMQ5/GxMtZa6zu8kFtN4DTvoWTYNg+I1/p9bhPS4SOhDXTTzVvqMGZwcVF1RbvYH5iXv2AwZpMHL/efLlVNEzNY0Br6rHkLLq/In07xJb2tyMw7m+pJxWrFB47HOhybMZENjptWwwuoxJTtdMOIAIErzWvccWmDn9vbjwWrUHDNhPG6XHlcvsarlTacCNgAvhusc9ZXl1FEQM64mj7ogLrN8OhVCEGTPPBF04PCGN0mEDJeK6msupFOYjAYeYKpiEMTM+4cVB5E5srAw3w+H4ZDkKvKwc9lQYL5P10ULE9RdmKjnYoNv1lsOjLdbyG5ih6CLlE5AyRDZyrpbBIlO94KC501hvixc6Unzm6yCsJ61t9JfbXlI3B76hcwYygEwtjhMnRo81vCheaexC7rQAi8PPM+JOeQbZMq7cVGo/1UvPKDrRjPdzfC0obCxX1t1hmhIZ51tZhNYiukkX2ij5IvOY5o9m3Nq828LfWHhtLp8O+k/9gbjfibOXipLiSyiNsXbIziyJOYO5jPWJe+jot1XNSPR9W+uDNqAbBaS8rMNIwf5yqnZYf/EbMK2Pnm654iHfPazsksXkTKxHxnTJHL61PzxCD03KshrqGCP4eWfNQow17mXOc5hvuiffbt78XVCLanOtxyHTITeb5SZ/HyR2UVK8w/4AgEpu5FDw9HmKJ3G+Gc6UTaLjKQN7EMvu75k4NGr4ZQrKz5QvjrtJyx/yN723kxThmzrrviT+pXPvtqFO59BicJEtU3GweePiVJONWSyITusyXgmnVSabePG3tZ3XN/m7WPDvW7NdjYC4EfMf0Gl4Xf/IYmVGQ52pkL/PKEYRL/SXWOOzOlYZADO8vALaS+Xy8U4fi+iVkKE7yhKTAFtxiw0Q0O13t6e/BxOarrBxwCZK2mzq6mdJHeA1d+HvEn0tKGDP4r+ZBmZyxnGcNpr7US+Qv0lDOUCTeCJixsMIah2WF7oh9BsDu2deTK52AHIY7RvvSK8HGr8NVNLB9xBKdra8+FQ9x9vHTSMcqA1QuM2KfgY6HNPDatEAd24SlyrjbygfrUF0d+/w9vmkNVkSok7QzDmFVhmlNxkxydvVE7A+pec/eSXrp/FxVcB4HQr4B2anTFFdSgc7PzAuFzI8Ov6sgpSrly5w1hgBA3oxjHA+pq0de4l2jD4DMjteym3GmScfJ+p2fL7AWwOt/Dnk7WZ/MOj/jfQ6ved8xrYy3xMtOvRjv1WfcZUeVeIk1PMMg9rYWmjWKxsGFxhggNkHlXZL2Rf4OpUpsxvXBuznTV1LP1AGQ6xJvQb/BmMQ4t6+al3XpMj+/NIG/rDDMYablR+1S83Z8t6utefh7LIz9fZOaZjZcekJOgdDRtnnHFdPDF/cKToz97LpMFAm7Ex8Y+7x4eW1dgN/CMoINDRrq1LwB2BuPJVlo7OXAoNJikcnzcKw3mPcmWBrPpTeQEeQnxPOY5EsbGBVxqTv70KuO8/lP85tIpvWy8L5bmMdfESY732ytwdxShi7tZ77U/Jytcx6MMg+P4Tmcp+qfIiuYJ5jO2DmwR1m2sLpmywor7CxTMOjoQv8zc5sbPWlHWv8Gag6sf4NctYFqmmWDydFUuCMtW2j72yX2H8V3MdtagL9JpBh9Px76Av5mCBNL1NCbyxsHr62hUlgiK+ghmmN+h8yDlZYh7GKOQcG4JdYYZ09EBiVz5lA7G3kzhMHLLIfDGdgjOVZH5Wxlbs1+S+A4WbrpSnMnAe3Ui6xFwvFATymriqa9G7KAaT1sZ08FxRsey87QmcaUI4ZPMBB5NFXbCOxM4lLKOoSIzerCOXVbh0CjOzab4ZwmNfi6UXjNdSb6JPHqt/QcMthyi3iY3s05kMn4DpuJMRIZoxmWELa2MzHlbhOlRY0ghBCVQQpLCFEZpLCEEJVBCksIURmksIQQlUEKSwhRGaSwhBCVQQpLCFEZpLCEEJVBCksIURmksIQQlUEKSwhRGaSwhBCVQQpLCFFaokTy2oawKi8jMiPaZo2A7GPesYWF70ZHk8+8PpNVQntrrPAQPvdZywF85sexeQ/e/6max9juii2qxuXR3Tre/8Sah1hY8Al81jQrgKgXxiqjrDD6tuVI4h2lWZL6M5BtIcvwGLtjTdAMS2QJGzV8DUIFxUKDVGAftnxh4cm0gQE/e3X83UpThP5gG7PjejxGpfkly7h+eg1sjHqm+bmxmGAX5GdszmDFwAKSX4RsYvkzDHKF+bn+ADILcinkE5phiUyIVnGsH3457sBj4+HRljPRUDetMssB3R3F+PKEN/qNe3k8z8HM0sQLcW5p09Fbcc7jsB2FbXdBvR+LUFbkaPPuRtfivN7B+fEGuCnkLM2wRFZwZsFBPM9EUXBJylr377XOgje/eVRW/CO2vK42l8ISmYCLii3Hn4ZcgTvimZzxhC1C5AeXvZz1bGwDBF1QIkvYvJPLQNp3fgz5VhiLhcgEKSyRGZhlLYfcADnX3ADPqf31UFrDTIgMkMISuQCltQDy19idbtk38hQDFCkskQl0r0O+Ctmsx7/oxcs7tKFoaDvaEeda6zXbytyTlWuMUg8YNkKDdMtNV0sGv8PNomlrCnXVW1JYIivYBZhLwaNxoa0Jl4lgQwb/TbbOgs6F/SFHUUFD2An5HMh8K0B58PuFfBS7J5kryVXWWcyAHG8eiMvzZcAqQx2m88Kih4GaumM6P3cakZrAFvDN3L1XWDFMhPwQciHkPBwzr6cuyF2Qn1sxLLdiZjgTzB0Ml0AuM7/7s5X9T/KIcg/4vofie30U28R83E6FXInPfNXyh9fRciuGX0L2gFyL8+UNgDMthnDcylb1e5v3s+dJP4yTzzNCuBA6qVU9zuV95ukujHP6Pc6pIQXEdJlGX9MKsSTc2jztawU+e6kVQMzquCxbmnfqSM1nMv1oCOTVvAM3az6LcBm4BJ9Z2MwqfldObJbhcxMrAHzmNubX/Sp85qLaf2wLGQ65MCKWK03EAI2wioNzGBq/yf6QTgsOFKJhao1aHCBcD59ublTsLurumDVVnmHFTGFnCBNsOVO4v8gZkhBlZr1cQgyMNzBgbjJPdByJfRq/Hitqij3QiWk/jY20T0zKq9qAEB0HDb0QenyYXLl7L+7q0lK1JWF4moZB/gIyxIQQvTKovydgAH0Am4MhdN3+tgrLxCotCXGsB5rXj+JsdkInOD2EyIt+y8vQ+4FBdY95vZ/PYJ9Z06xP82KaTS0aB9/jrtgMNffO/q6q9kIhiqSuelgYTG9h81zUpeFsgHWPOMDGmGiI8MIebh5XNRnf7UwTQuQHY3sg+0EuYpRv2cqIlNGGFXaqAyBfZ+Ruj7QOIUQd9GvD6osIahxuXr/7ScisooLK+qJsNizGUZl7Xpm+8ljMWIUQDdKSwiKRNsJcH0bMM/KWxf+LCuHf0DF1WZsVVsw6mUt3iHlcGw3qi00I0TQt13SPGC16uGbETOJkbBk/9MRA9XjFzJPfBR0VY2WnEiIbMrU9RUMAJrty1nVGzHQGFDjnvbA5xTzf6yYpKyGyI/OuOdGxZCEGLvulnYAtkxZZXmRRp0bMx/KPsyn2yJuD87zOhBCZ07INqz9ixsFSESw3wry4Ny1nirRhRc3yEyAvmMenvVAGx4MQnUjuCotgUDPmiJ1cdzKvQPlsnvatIhRWxFMxJm1781pIC+T9EyJfClFYKTHIR5gvRcdjgM+xHMhTYYVXdF/zGmKsvaTgWSEKolCFlcL6W9gcZV458basKybmobCi7MsO5nFnTE9id+NVWv4JURxtUVgkDNW0bbHuE5eHD2RV9ylrhRUK9ggI7W/j2BHGhBCFk7mXsF4icXoqlAGjv6m02HVlCrbTiyz92hc4nvebL/8YAMrGA7na3oQQfdO2GVZPonjdyebxSxOhGGZZk7Q6w4pjYSrNGjuVefS+DOpCtJnSKCwSBm0uvzirYQ3zO5pZJraisMKj+ScQVqbgMvUlE0KUgrYtCXsjAktfpLABA7anYvs4ts/lvRRjBQrzsjmMG7um3fmQQoh3U6oZVk/ChnSQeXI1vYnP1/m6LqtzhhXG/2HmPfTYVn2K7FRClJNSKywS4QTsTcbOr6+ZJ1rP66vaaT0KK+xU7E7DgFYqwql4/jITQpSW0iuslLBv0RDO9tVUXPexy88GnttlfSgs/J+NPpn3xxiqB9Zr0iiEEFnBGRdkD8h5sR3cy3O6elYcxd/scr1lNIw9n11le3utEKK8VGaG1ZNY0nGWRDsX47empcvEnjOseO5hkO3M7VRPdWrlCCE6mcoqLBIGcyYf0yi/FeRuyErzFJouyAPmZV9YTI/pP5NkpxKiulRaYdUC5UUlday5AZ25fgyLYAoNH3+wXg+jEKK8dIzCIlENgp2Tz4ZwyfcLyGxFqQshhBCiUP4fbxlr2vFQYKoAAAAASUVORK5CYII=" alt="">
					</a>
				</div>
				<!-- burger toggler -->
				<div class="menu-burger d-xl-none d-flex justify-content-end align-items-center col-3 ml-auto">
					<svg width="40" height="40" viewBox="0 0 40 40" xmlns="https://www.w3.org/2000/svg">
						<path d="M40 28.8896H0V33.3341H40V28.8896Z" fill="#ffffff"/>
						<path d="M40 17.7783H0V22.2228H40V17.7783Z" fill="#ffffff"/>
						<path d="M40 6.66699H0V11.1115H40V6.66699Z" fill="#ffffff"/>
					</svg>
				</div>
				<div class="col-xl-10 col-lg-10">
					<nav id="site-navigation" class="main-navigation">
						<?php
							wp_nav_menu(
								array(
									'theme_location' => 'header-menu',
									'menu_id'        => 'header-menu',
									'menu_class'     => 'header-menu',
									'fallback_cb'    => '',
								)
							);
						?>
				</nav><!-- #site-navigation -->
			</div>
			<!-- /.col-xl-4 -->
    </div>
		<!-- /.row -->
  </div>
	<!-- /.container -->
</header><!-- #masthead -->