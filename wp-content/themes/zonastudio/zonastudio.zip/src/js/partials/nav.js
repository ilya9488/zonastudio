// Sticky Header
$(window).scroll(function () {
  stickyHeader(15)
})

$(document).mouseup(function (e) {
  let els = $('.menu-burger')
  let langDrop = $('li.pll-parent-menu-item')
  if (!els.is(e.target) && els.has(e.target).length === 0) {
    $('.menu-menu-glowne-container').removeClass('open')
    $('.menu-burger').removeClass('open')
  }
  // lang dropdown
  if (!langDrop.is(e.target) && langDrop.has(e.target).length === 0) {
    $('li.pll-parent-menu-item').removeClass('open')
  }
})

function stickyHeader(toggleTop) {
  const top = $(window).scrollTop()
  if (top >= toggleTop) {
    $('header#masthead').addClass('sticky-bg')
    $('header#masthead').removeClass('sticky-add')
  } else {
    $('header#masthead').removeClass('sticky-bg')
    $('header#masthead').addClass('sticky-add')
  }
}

stickyHeader(15)

$('.menu-burger').on('click', function menuHead() {
  if ($(this).hasClass('open')) {
    $(this).removeClass('open')
    $('.menu-menu-glowne-container').removeClass('open')
    $('.site-header').removeClass('burger-open')
    stickyHeader(1)
  } else {
    $(this).addClass('open')
    $('.menu-menu-glowne-container').addClass('open')
    $('.site-header').addClass('burger-open')
    stickyHeader(-1)
  }
})