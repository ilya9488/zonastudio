$(document).ready(function () {
  // code
});