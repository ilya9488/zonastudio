// All Inputs Autocomplete Off (!)
$('input').attr('autocomplete', 'off')

// Smooth anchor scrolling
// $(document).on('click', 'a[href^="#"]', function (event) {
//   event.preventDefault();
//   $('html, body').animate({
//     scrollTop: $($.attr(this, 'href')).offset().top
//   }, 500);
// });

// site-btn
$('.site-btn').each(function () {
  $(this).append('<span class="line_1 line"></span><span class="line_2 line"></span><span class="line_3 line"></span><span class="line_4 line"></span>')
})

// h = w ( gallery )
function gallery() {
  $('.home-last-posts .wrap').each(function () {
    $(this).css('height', $(this).width())
  })
}
$(window).on('resize', gallery)
gallery();

// scrollbarWidth
function scrollbarWidth() {
  var documentWidth = parseInt(document.documentElement.clientWidth);
  var windowsWidth = parseInt(window.innerWidth);
  var scrollbarWidth = windowsWidth - documentWidth;
  return scrollbarWidth;
}

// 
$('[data-toggle="modal"]').on('click', function () {
  document.body.style.marginRight = `${scrollbarWidth()}px`
})
$('.modal').on('hide.bs.modal', function () {
// $('.modal').on('click', function () {
  document.body.style.marginRight = `0px`
})

// $('.modal').on('shown.bs.modal', function () {
  // ( ? )
// })

// 
$('.hover-wrap').on('click', function () {
  $('.hover-wrap').each(function () {
    $(this).removeClass('add-hover')
  })
  $(this).addClass('add-hover')
})


let arr1 = [], i_hed = 0;
$('.tariff-plan .tariff-title').each( function () {
  i_hed++; arr1.push($(this).outerHeight()); return arr1;
})
$('.tariff-plan .tariff-title').each( function () {
  $(this).css('min-height', Math.max.apply(null, arr1))
})
// console.log(Math.max.apply(null, arr1));

// Swiper: Slider
const swiper = new Swiper('.slider-gullery', {
  loop: true,
  // preloadImages: false,
  // lazy: true,
  speed: 500,
  pagination: {
    el: '.slider-pagination',
    type: 'fraction',
  },
  navigation: {
    nextEl: '.next-arrow',
    prevEl: '.prev-arrow',
  },
});