<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Zonastudio
 */

?>

<div class="col-md-4 col-6 px-md-10" <?php if (have_rows('fields')): while (have_rows("fields")) : the_row(); if( get_sub_field('project_photo') ): ?> data-toggle="modal" data-target="#modal_<?= $i; ?>" data-whatever="@getbootstrap" <?php else: ?> title="Brak zdjęć projektu." data-photo="false" <?php endif; ?> <?php endwhile; else: ?> title="Brak zdjęć projektu." data-photo="false" <?php endif; ?>>
	<div class="wrap" style="background-image: url(<?php if(get_the_post_thumbnail()){ echo wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full')[0]; }else{ if (have_rows('fields')): while (have_rows("fields")) : the_row(); $images = get_sub_field('project_photo'); if( $images): echo esc_url($images[0]['sizes']['post-full']); else: echo get_template_directory_uri().'/static/img/bez-zdjęć.jpg'; endif; endwhile; endif; }?> );">
		<div class="text-wrap hover-wrap">
			<h4 class="title"><?php the_title(); ?></h4>
			<?php if (have_rows('fields')): while (have_rows("fields")) : the_row(); ?>
				<?php if(get_sub_field('apartament_mkv')):?>
					<div class="delimer"></div>
					<span class="apartament">Apartament <?php the_sub_field('apartament_mkv');?> mkv</span>
				<?php endif;?>
			<?php endwhile; endif; ?>
			<div class="line-1"></div><div class="line-2"></div><div class="line-3"></div><div class="line-4"></div>
		</div>
	</div>
</div>
<?php if (have_rows('fields')): while (have_rows("fields")) : the_row(); $images = get_sub_field('project_photo'); if( $images ): ?>
	<div class="modal" id="modal_<?= $i; ?>" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<svg class="close-icon" width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="https://www.w3.org/2000/svg">
					<path d="M30 60C13.4315 60 0 46.5685 0 30C0 13.4315 13.4315 0 30 0C46.5685 0 60 13.4315 60 30C60 46.5685 46.5685 60 30 60Z" fill="white"/>
					<path fill-rule="evenodd" clip-rule="evenodd" d="M29 29.7499L42.252 17L44 18.6833L32.5011 29.7499L44 40.8167L42.252 42.5L29 29.7499V29.7499Z" fill="#C59D5F"/>
					<path fill-rule="evenodd" clip-rule="evenodd" d="M32 29.7499L18.748 17L17 18.6833L28.4989 29.7499L17 40.8167L18.748 42.5L32 29.7499V29.7499Z" fill="#C59D5F"/>
				</svg>
			</button>
			<div id="slider_gullery_<?= $i; ?>" class="slider-gullery">
				<div class="swiper-wrapper">
					<?php $i = 0; foreach( $images as $image ): ?>
						<div class="swiper-slide slider-item <?php if($i === 0) echo 'active'; ?>">
							<img class="slider-gullery-img" src="<?php echo esc_url($image['sizes']['post-full']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
						</div>
					<?php $i++; endforeach; ?>
				</div>
				<div class="prev-arrow slider-arrow"><svg class="prev-arrow slider-arrow-img" width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="https://www.w3.org/2000/svg"><path d="M30 60C13.4315 60 0 46.5685 0 30C0 13.4315 13.4315 0 30 0C46.5685 0 60 13.4315 60 30C60 46.5685 46.5685 60 30 60Z" fill="white"/><path fill-rule="evenodd" clip-rule="evenodd" d="M20.25 29.9999L33.502 17.25L35.25 18.9333L23.7511 29.9999L35.25 41.0667L33.502 42.75L20.25 29.9999Z" fill="#C59D5F"/></svg></div>
				<div class="next-arrow slider-arrow"><svg class="next-arrow slider-arrow-img" width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="https://www.w3.org/2000/svg"><path d="M30 60C46.5685 60 60 46.5685 60 30C60 13.4315 46.5685 0 30 0C13.4315 0 0 13.4315 0 30C0 46.5685 13.4315 60 30 60Z" fill="white"/><path fill-rule="evenodd" clip-rule="evenodd" d="M39.75 29.9999L26.498 17.25L24.75 18.9333L36.2489 29.9999L24.75 41.0667L26.498 42.75L39.75 29.9999Z" fill="#C59D5F"/></svg></div>
				<div class="slider-pagination"></div>
			</div>
		</div>
		<div class="permalink">
			<a class="site-btn" href="<?= get_permalink(); ?>" target="_blank" rel="noopener noreferrer">zobacz ten projekt</a>
		</div>
	</div>
<?php endif; endwhile; endif; ?>