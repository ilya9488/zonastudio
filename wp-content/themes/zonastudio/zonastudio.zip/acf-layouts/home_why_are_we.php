<section class="about-us">
  <div class="container">
    <div class="row">

      <div class="col-md-6 img-wrap">
        <?php echo wp_get_attachment_image(get_sub_field('image'), 'about-us', '', ['class' => 'about-us-img']);?>
      </div>

      <div class="col-md-6 text-wrap">
        <h2 data-bg-text="<?php the_sub_field('text_bg'); ?>"><?php the_sub_field('title'); ?></h2>
        <div class="text"><?php the_sub_field('text'); ?></div>
        <a class="site-btn" href="<?php the_sub_field('page_link'); ?>">
          <?php the_sub_field('page_title'); ?>
        </a>
      </div>

    </div>
  </div>
</section>