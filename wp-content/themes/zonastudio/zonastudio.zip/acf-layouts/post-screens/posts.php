<section class="home-last-posts">
  <div class="container-xl">
    <div class="row">
      qweqwe12313werrw я
    </div>
  </div>
</section>