// $(window).on('load', function () {
//   // $('body').removeClass('preloader');
//   $('.preloader').animate({opacity: 0}, 500)
//   // $('.preloader').animate({width: 0, height: 0, opacity: 0}, 500)
//   setTimeout( function () {
//     $('.preloader').remove();
//   }, 500)
// });
