<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Zonastudio
 */

?>

<footer class="footer site-footer">
	<div class="footer-wrap" style="background-image: url(<?php echo get_template_directory_uri();?>/static/img/footer-bg.png) ;">
		<?php if (get_field('show_footer_form') || is_404()) { ?>
		<!-- FORM -->
		<div class="container-xl container-fluid">
			<div class="row">
				<div class="col-12">
					<div class="footer-form-wrap" style="background-image: url(<?php echo get_template_directory_uri();?>/static/img/contact-us-footer-bg-text.png) ;">
						<div class="footer-form" style="background-image: url(<?php echo get_template_directory_uri();?>/static/img/footer-form-bg-transp.png) ;">
							<h2>Get In Touch</h2>
							<div class="dropdown">
								<div class="select d-flex justify-content-between align-items-center wpcf7-form-control wpcf7-select wpcf7-validates-as-required message-subject">
									<span class="message">Message Subject</span> <span class="icon icon-bracket-accordion "></span>
								</div>
								<ul class="dropdown-menu">
								<?php
									$rows = get_field('message_subjects', 'option');
									if ($rows) {
										$i = 0;
									foreach ($rows as $row) { ?>
										<li><?php echo $row['message_subject']; ?></li>
									<?php $i++;
											}
										} else{
									?>
										<li>Motor Vehicles</li>
										<li>Beauty</li>
										<li>Medical </li>
										<li>Sport</li>
										<li>Cafe & Restaurants</li>
										<li>Groceries</li>
										<li>Shops</li>
									<?php } ?>
									</ul>
								</div><!-- /.dropdown -->
								<?php echo do_shortcode( '[contact-form-7 id="31" title="Untitled"]' ); ?>
						</div><!-- /.footer-form -->
					</div><!-- /.footer-form-wrap -->
				</div><!-- /.col-12 -->
			</div><!-- /.row -->
		</div><!-- /.container -->
		<?php } ?>

		<div class="container-xl container-fluid">
			<div class="row">

				<div class="col-xl-5 col-lg-4 col-md-4 col-sm-12">
					<a class="link-footer-logo" href="<?php echo site_url();?>">
						<svg class="footer-logo">
							<use xlink:href="<?php echo get_template_directory_uri();?>/static/svg/sprite.svg#footer-logo"></use>
						</svg>
					</a>
					<p>
						<?php if(!empty(get_field('text_under_logo', 'options'))) { ?> 
							<?php the_field('text_under_logo', 'options');?>
						<?php } else { ?>
							With Hour Pi, you will always be the first one to get the best of life. Reliable protection and the best places around you in New York and the Tri-State area, or search for something new. We always have tons of cool things to offer.
						<?php }  ?>
					</p>
				</div>
				<div class="col-xl-2 col-lg-3 col-md-3 col-sm-4 col-6 offset-xl-2 offset-lg-1 offset-md-2">
					<div class="about-us-wrap">
						<?php $menu_location = 'menu-2';
									$menu_locations = get_nav_menu_locations();
									$menu_object = (isset($menu_locations[$menu_location]) ? wp_get_nav_menu_object($menu_locations[$menu_location]) : null);
									$menu_name = (isset($menu_object->name) ? $menu_object->name : 'About Us'); ?>
						<h5><?php	echo esc_html($menu_name); ?></h5>
						<?php
								wp_nav_menu(
									array(
										'theme_location' => 'menu-2',
										'menu_id'        => 'about-us-menu',
									)
								);
							?>
					</div><!-- /.about-us-wrap -->
				</div>
				<div class="col-xl-2 col-lg-3 col-md-3 col-sm-4 col-6 offset-xl-1">
					<div class="support-wrap">
						<?php $menu_location = 'menu-3';
									$menu_locations = get_nav_menu_locations();
									$menu_object = (isset($menu_locations[$menu_location]) ? wp_get_nav_menu_object($menu_locations[$menu_location]) : null);
									$menu_name = (isset($menu_object->name) ? $menu_object->name : 'Support'); ?>
						<h5><?php	echo esc_html($menu_name); ?></h5>
						<?php
								wp_nav_menu(
									array(
										'theme_location' => 'menu-3',
										'menu_id'        => 'support-menu',
									)
								);
							?>
						<!-- <button class="btn dropdown-toggle lang-btn pl-2" data-target="#drop" data-toggle="collapse" aria-expanded="false" aria-controls="drop"><span class="icon icon-en"></span> En</button>
						<div id="drop" class="dropdown-menu">
							<a class="dropdown-item" href="#" data-target="#drop" data-toggle="collapse" aria-expanded="false" aria-controls="drop"> <span class="icon icon-en"></span> En</a>
						</div> -->
						<!-- /.drop -->
					</div><!-- /.support-wrap -->
				</div><!-- /.col-xl-2 -->
				<div class="col-12">
					<div class="footer-text d-md-flex justify-content-md-between">
						<span>© <?= date("Y") ?> <?php the_field('designed_and_developed_text', 'options');?> <a target="_blank" href="<?php the_field('development_link', 'option');?>"><?php the_field('designed_and_developed_name', 'options');?></a> </span>
						<span class="text-md-right"><?php the_field('copyright_beginning_text', 'options');?> © <?= date("Y") ?> <a target="_blank" href="<?php the_field('development_link', 'option'); ?>"><?php the_field('copyright_nmae', 'options');?></a> - <?php the_field('copyright_end_text', 'options');?></span>
					</div><!-- /.footer-text -->
				</div><!-- /.col-12 -->
			</div><!-- /.row -->
		</div><!-- /.container -->
</div><!-- /.footer-wrap -->
</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
