$(window).on('load', function () {
  $('body').removeClass('preloader');
  $('.preloader-wr').remove();
});
