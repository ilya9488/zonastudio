/*
 * Plugins
 */

/*
 * Custom
 *
 */
//= ../../node_modules/bootstrap/js/dist/util.js
//= ../../node_modules/bootstrap/js/dist/collapse.js
//= ../../node_modules/bootstrap/js/dist/dropdown.js


//= partials/functions.js
//= partials/preloader.js

//= ../../node_modules/slick-carousel/slick/slick.min.js

$(document).ready(function () {
  //= partials/app.js
  //= partials/nav.js
});